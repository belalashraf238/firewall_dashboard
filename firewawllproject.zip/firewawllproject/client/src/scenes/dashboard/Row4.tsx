import { useState } from "react";
import { Link } from "react-router-dom";
import PixIcon from "@mui/icons-material/Pix";
import { Box, Typography, useTheme } from "@mui/material";
import BoxHeader from "@/components/BoxHeader";
import DashboardBox from "@/components/DashboardBox";
import FlexBetween from "@/components/FlexBetween";
import {
    ResponsiveContainer,
    CartesianGrid,
    AreaChart,
    BarChart,
    Bar,
    LineChart,
    XAxis,
    YAxis,
    Legend,
    Line,
    Tooltip,
    Area,
  } from "recharts";
import { useGetThreatQuery } from "@/state/dataApi";
import React, { useMemo } from "react";

 


const Row4 = () => {
  const { palette } = useTheme();
  const {data}=useGetThreatQuery();
  const thrats = useMemo(() => {
    return (
      data &&
      data.map(({ name, value }) => {
        return {
          name: name,
          value: value
        };
      })
    );
  }, [data]);
  
  return (
    <DashboardBox gridArea="m">
        <BoxHeader
          title="Revenue and Expenses"
          subtitle="top line represents revenue, bottom line represents expenses"
          sideText="+4%"
        />
       
        <ResponsiveContainer >
          <LineChart
            
            data={thrats}
            margin={{
              top: 20,
              right: 0,
              left: -10,
              bottom: 55,
            }}
          >
            <CartesianGrid vertical={false} stroke={palette.grey[800]} />
            <XAxis
              dataKey="name"
              tickLine={false}
              style={{ fontSize: "10px" }}
            />
            <YAxis
              yAxisId="left"
              tickLine={false}
              axisLine={false}
              style={{ fontSize: "10px" }}
            />
            <YAxis
              yAxisId="right"
              orientation="right"
              tickLine={false}
              axisLine={false}
              style={{ fontSize: "10px" }}
            />
            <Tooltip />
            <Legend
              height={20}
              wrapperStyle={{
                margin: "0 0 10px 0",
              }}
            />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="value"
              stroke={palette.tertiary[500]}
            />
           
          </LineChart>
        </ResponsiveContainer>

        

          




    </DashboardBox>
    
  );
};

export default Row4;