import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const dataApi = createApi({
  baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:8000/" }),
  reducerPath: "main",
  tagTypes: ["logs", "threats", "locations","stats"],
  endpoints: (build) => ({
    getLog: build.query({
      query: () => "log/logs/",
      providesTags: ["logs"],
    }),
    getThreat: build.query({
      query: () => "threat/threats/",
      providesTags: ["threats"],
    }),
    getLocation: build.query({
      query: () => "threat/locations/",
      providesTags: ["locations"],
    }),
    getStats: build.query({
        query: () => "state/stats/",
        providesTags: ["stats"],
      }),
  }),
});




export const { useGetLogQuery,useGetLocationQuery,useGetStatsQuery,useGetThreatQuery } =
  dataApi;
